package com.dxc.pms.model;

public class Product {
	private int productid;
	private String productName;
	private int quantityOnHand;
	private int price;
	
	public Product() {
		
	}
	
	public Product(int productid, String productName, int quantityOnHand, int price) {
		super();
		this.productid = productid;
		this.productName = productName;
		this.quantityOnHand = quantityOnHand;
		this.price = price;
	}
	@Override
	public String toString() {
		return "Product [productid=" + productid + ", productName=" + productName + ", quantityOnHand=" + quantityOnHand
				+ ", price=" + price + "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + price;
		result = prime * result + ((productName == null) ? 0 : productName.hashCode());
		result = prime * result + productid;
		result = prime * result + quantityOnHand;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Product other = (Product) obj;
		if (price != other.price)
			return false;
		if (productName == null) {
			if (other.productName != null)
				return false;
		} else if (!productName.equals(other.productName))
			return false;
		if (productid != other.productid)
			return false;
		if (quantityOnHand != other.quantityOnHand)
			return false;
		return true;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getQuantityOnHand() {
		return quantityOnHand;
	}
	public void setQuantityOnHand(int quantityOnHand) {
		this.quantityOnHand = quantityOnHand;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getProductid() {
		return productid;
	}
	
	
}
