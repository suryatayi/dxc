package com.dxc.pms.client;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Scanner;

import com.dxc.pms.dbcon.MyConnection;

public class Client { 
    static Scanner scanner = new Scanner(System.in);
public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Connection con = MyConnection.getDBConnection();
 
        while (true) {
 
            System.out.println("MAIN MENU");
            System.out.println("1. Add Product");
            System.out.println("2. Delete Product");
            System.out.println("3. Update Product");
            System.out.println("4. Find Product by Id");
            System.out.println("5. Find All Products ");
            System.out.println("6. E X I T");
            System.out.print("Please enter your choice (1-6)");
            int choice = scanner.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Adding Products : ");
                addProducts(con);
                break;
            case 2:
                System.out.println("Deleting Products : ");
                deleteproducts(con);
                break;
            case 3:
                System.out.println("Updating Products : ");
                updateproducts(con);
                break;
            case 4:
                System.out.println("Finding Products by id : ");
                displayproductById(con);
                break;
            case 5:
                displaydetails(con);
                break;
            case 6:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option Please select (1-6)");
            }
        }
    }

private static void updateproducts(Connection con) throws SQLException {
	System.out.println("Enter product id to update : ");int productid= scanner.nextInt();
	System.out.println("Enter product name to update : ");String productName= scanner.next();
	System.out.println("Enter product quantity to update : ");int QuantityOnHands= scanner.nextInt();
	System.out.println("Enter product price to update: ");int price= scanner.nextInt();

	PreparedStatement statement = con.prepareStatement("update hr.product set productName =?,quantityOnHand=?,price=? where productid=?");
	statement.setInt(4, productid);
	statement.setString(1, productName);
	statement.setInt(2, QuantityOnHands);
	statement.setInt(3, price);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(productName+",successfully updated");	
}

private static void deleteproducts(Connection con) throws SQLException {
	System.out.println("Enter product id : ");int productid= scanner.nextInt();
	
	PreparedStatement statement = con.prepareStatement("delete from hr.product where productid = ?");
	statement.setInt(1, productid);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(productid+",successfully deleted");
		
}

private static void addProducts(Connection con) throws SQLException {
	System.out.println("Enter product id : ");int productid= scanner.nextInt();
	System.out.println("Enter product name : ");String productName= scanner.next();
	System.out.println("Enter product quantity : ");int QuantityOnHands= scanner.nextInt();
	System.out.println("Enter product price: ");int price= scanner.nextInt();

	PreparedStatement statement = con.prepareStatement("insert into hr.product values(?,?,?,?)");
	statement.setInt(1, productid);
	statement.setString(2, productName);
	statement.setInt(3, QuantityOnHands);
	statement.setInt(4, price);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(productName+",successfully saved");
	

}

private static void displayproductById(Connection con) throws SQLException {
	System.out.println("Product displaying by id:");
	System.out.println("Product enter the product id to search:");
	int productid = scanner.nextInt();
	System.out.println("You want to Search for :" +productid);
	PreparedStatement stat= con.prepareStatement("select * from hr.product where productid = ?");
	stat.setInt(1, productid);
	ResultSet res = stat.executeQuery();
	if(res.next()) {
		System.out.println(res.getString(1)+ " ");
		System.out.println(res.getString(2)+ " ");
		System.out.println(res.getString(3)+ " ");
		System.out.println(res.getString(4)+ " ");
	}

}

public static void displaydetails(Connection con) throws SQLException {
	System.out.println("Displaying all the  Products : ");
	Statement statement= con.createStatement();
	ResultSet res = statement.executeQuery("select * from hr.product");
	while(res.next()) {
		System.out.println(res.getString(1)+ " ");
		System.out.println(res.getString(2)+ " ");
		System.out.println(res.getString(3)+ " ");
		System.out.println(res.getString(4)+ " ");
	}
	//metadata
	ResultSetMetaData rsmd =res.getMetaData();
	
	int columnNumber = rsmd.getColumnCount();
	
	for(int i =1;i<=columnNumber;i++)
	{
		System.out.print(rsmd.getcoloumnName(i)+" ");
	}
	System.out.println();
	while(res.next()) {
		for(inti=1;i<columnNumber;i++) {
			System.out.println(res.getString(i)+" ");
		}
		System.out.prinln();
		
		}
	}
}
}
