import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class FetchFromDB {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		//1.Loading the driver
		Class.forName("oracle.jdbc.driver.OracleDriver");
		System.out.println("Driver Loaded");
		
		//2. Creating connection
		Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "surya");
		System.out.println("Connected");
		
		//Creating Statement
		Statement stat = con.createStatement();
		
		//4.Executing Queries
		ResultSet res = stat.executeQuery("select * from hr.employees");
		
		//5.Reading the results
		while (res.next()) {
			System.out.print(res.getString("first_name" )+ " ");
			System.out.println(res.getString("salary"));
		}
		stat.close();
		con.close();
	}

}
