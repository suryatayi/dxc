
public class StringDemo2 {

	public static void main(String[] args) {
		String name1 = "surya";
		String name2 = new String("surya");
		System.out.println(name1.equals(name2)); //values true
		System.out.println(name1==name2);        //reference address falses 	
	}

}
