
public class VariableDemo {

	byte roll=19;
	short salary=2000;
	int grade=19999;
	long budget=4000;
	float marks=45.5f;
	char alphabet='s';
	double amount=987;
	boolean married=true;
	String name = "surya tayi";
	public void display() {
		System.out.println("rollnumber  is :" +roll);
		System.out.println("salary is :" +salary);
		System.out.println("grade =" +grade);
		System.out.println("budget =" +budget);
		System.out.println("total marks :" +marks);
		System.out.println("first letter :" +alphabet);
		System.out.println("amount =" +amount);
		System.out.println("married :" +married);
		System.out.println("My name is  :" +name);
	}
	public static void main(String[] args) {
		VariableDemo d = new VariableDemo();
		d.display();

	}

}
