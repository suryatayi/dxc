import java.util.Scanner;
public class Bike {
	Scanner sc = new Scanner(System.in);
	String modelnumber;
	String colour;
	int price;
	String bikenumber;
	public void start() {
		System.out.println("Bike Started :"+bikenumber);
	}
	public void stop() {
		System.out.println("Bike Stopped :"+bikenumber);
	}
	public void details() {
		System.out.println("---------DETAILS---------\n");
		System.out.println("Bike colour :"+colour);
		System.out.println("Bike modelnumber :"+modelnumber);
		System.out.println("Bike price :"+price);
		System.out.println("Bike number :"+bikenumber);

	}
	public void acceptdetails() {
		
		System.out.print("Enter Bikecolour:");
		colour =sc.next();
		System.out.print("Enter modelnumber:");
		modelnumber =sc.next();
		System.out.print("Enter price:");
		price =sc.nextInt();
		System.out.print("Enter Bikenumber:");
		bikenumber=sc.next();
	
	}

	public static void main(String[] args) {
		Bike b=new Bike();
		b.acceptdetails();
		b.start();
		b.stop();
		b.details();

	}

}
