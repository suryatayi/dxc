
public class Constructor {
	static String surya;
	public Constructor() {
		System.out.println("surya");
	}
	public Constructor(String str) {
		System.out.println("tayi");
	}

	public static void main(String[] args) {
		Constructor c = new Constructor(surya); 

	}

}
