
public class ProductConstructor {
	private int productid;
	private String productname;
	private int quantityonhands;
	private int price;
	public ProductConstructor() {
		productid = 100;
		productname= "not available";
		quantityonhands= 0;
		price = 0;
	}
	public ProductConstructor(int productid, String productname) {
		super();
		this.productid = productid;
		this.productname = productname;
	}
	public ProductConstructor(int productid, String productname, int quantityonhands, int price) {
		super();
		this.productid = productid;
		this.productname = productname;
		this.quantityonhands = quantityonhands;
		this.price = price;
	}
	public void display() {
	System.out.println("Product id is:"+productid);
	System.out.println("Product name is:"+productname);
	System.out.println("Product quantity on hands is:"+quantityonhands);
	System.out.println("Product price is:"+price);
	}
	
	public static void main(String[] args) {
		ProductConstructor pc = new ProductConstructor(123, "Amway");
		ProductConstructor pc1 = new ProductConstructor(145, "lakme", 400, 600);
		pc.display();
		pc1.display();
	}

}
