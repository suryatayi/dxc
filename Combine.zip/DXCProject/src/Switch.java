import java.util.Scanner;

//switch demo
public class Switch{

 int week =0;
 Scanner sc = new Scanner(System.in);
 public void display() {
  System.out.print("Enter the week number (1-7 ) - Monday as 1 ..");
  week = sc.nextInt();
  switch (week) {
  case 1:
   System.out.println("Today is monday");
   break;
  case 2:
   System.out.println("Today is tuesday");
   break;
  case 3:
   System.out.println("Today is wednesday");
   break;
  case 4:
   System.out.println("Today is thursday");
   break;
  case 5:
   System.out.println("Today is friday");
   break;
  case 6:
  case 7:
   System.out.println("WEEKEND");
   break;
  default:
   System.out.println("Invalid week number");
  }
 }
 public static void main(String[] args) {
  Switch s = new Switch();
  s.display();
 }

}