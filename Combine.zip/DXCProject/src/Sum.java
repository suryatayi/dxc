import java.util.Scanner;

public class Sum {
	Scanner sc =new Scanner(System.in);
	int firstnumber=0;
	int secondnumber=0;
	int add;
	public void display() {
		System.out.print("Enter your first number:");
		firstnumber=sc.nextInt();
		System.out.print("Enter your second number:");
		secondnumber=sc.nextInt();
		
		add=firstnumber+secondnumber;
		System.out.println("sum is " +firstnumber+ "+" +secondnumber+ "=" +add);
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sum s=new Sum();
		s.display();
	}

}
