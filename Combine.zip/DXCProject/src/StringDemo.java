
public class StringDemo {

	public static void main(String[] args) {
		String name = "surya";
		name.concat("tayi");
		name.concat("venkata");
		System.out.println(name);
		name ="sai "+ name;
		System.out.println(name);
	}

}
