
public class Operator {
	int num1=110,num2=100,num3=200;
	public void display()
	{
		boolean result = num1>num2 || num1>num3;
		System.out.println("Result is :"+result);
	}

	public static void main(String[] args) {
		Operator o =new Operator();
		o.display();
	}

}
