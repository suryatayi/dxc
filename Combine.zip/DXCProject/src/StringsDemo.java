
public class StringsDemo {
	private int roll;
	private String studentName;
	private String studentAddress;
	private String emailAddress;
	private int marks;
	
	public StringsDemo() {
		
	}
	
	public StringsDemo(int roll, String studentName, String studentAddress, String emailAddress, int marks) {
		super();
		this.roll = roll;
		this.studentName = studentName;
		this.studentAddress = studentAddress;
		this.emailAddress = emailAddress;
		this.marks = marks;
	}

	
	@Override
	public String toString() {
		return "StringsDemo [roll=" + roll + ", studentName=" + studentName + ", studentAddress=" + studentAddress
				+ ", emailAddress=" + emailAddress + ", marks=" + marks + "]";
	}

	public static void main(String[] args) {
		StringsDemo s= new StringsDemo(12, "kamal", "kadiri"," tvsurya99@gmail.com", 90);
		System.out.println(s);
	}

}
