import java.util.Scanner;

public class Operator2 {
	Scanner sc = new Scanner(System.in);
	int marks=0;
	String result;
	public void display()
	{
		System.out.print("enter marks");
		marks= sc.nextInt();
		result = marks<33 ?"Fail":"pass" ;
		
		System.out.println("Result is :"+result);
	}

	public static void main(String[] args) {
		Operator2 o =new Operator2();
		o.display();
	}
 
}