import java.util.Scanner;

public class Readprogram {
	Scanner sc = new Scanner(System.in);
	int employeeage=0;
	String employeename;
	public void display() {
		System.out.print("please enter your age:");
		employeeage=sc.nextInt();
		
		System.out.print("please enter your name:");
		employeename=sc.next();
		
		System.out.println(employeename+",your age is: "+employeeage);
		
				
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Readprogram r=new Readprogram();
		r.display();
	}

}
