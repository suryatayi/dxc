import java.util.Scanner;

//accept three numbers ( 1 - 100 ) 
// negative are entered , you exit
// but if numbers are greater than 100 , then ignore
/*
 * Enter enter a number :3
 * Enter enter a number :110 (continue)
 * Enter enter a number :6
 * 
 * Result : 9
 * 
 * 2nd Scenario
 *  Enter enter a number :3
 * Enter enter a number :-110  (break)
 * 
 * Thanks 
 * Result  : 3
 */
public class LoopDemo {

 Scanner sc = new Scanner(System.in);
 int num,result; 
 public void demo() {
  for (int i = 1; i <= 3; i++) {
    System.out.println("Enter a number : ");
    num = sc.nextInt();
    if( num > 100)
      continue;
    else if( num < 0)
      break;
    result += num;
  }
  System.out.println("Result is :"+result);
 }

 public static void main(String[] args) {
  LoopDemo d = new LoopDemo();
  d.demo();
 }
}