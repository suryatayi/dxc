package Abstract;

interface Radio{
	int STATION_NUMBER = 90;
	void changeFrequency();
}
interface MusicPlayer{
	void play();
	void pause();
}
class ElectronicDevice{
	int price;
	String modelName;
}
class MobilePhone extends ElectronicDevice implements Radio,MusicPlayer{
	public void changeFrequency() {
		System.out.println("change frequency to "+STATION_NUMBER);
	}
	public void play() {
		System.out.println("start playing");
	}
	public void pause() {
		System.out.println("stop playing");

	}
}


public class InterfaceDemo {

	public static void main(String[] args) {
		MobilePhone o = new MobilePhone();
		o.changeFrequency();
		o.play();
		o.pause();
	}

}
