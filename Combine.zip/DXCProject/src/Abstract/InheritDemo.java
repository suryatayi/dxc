package Abstract;

abstract class Animal
{
	public abstract void eat();
	public void eatType() {
		System.out.println("Chewing like a cow");
	}
	public abstract void walk(); 
}
class Dog extends Animal{
	@Override
	public void eat() {
		System.out.println("Started eating ");
	}
	@Override
	public void walk() {
		System.out.println("Then Walking like a tortoise");
		
	}
}

public class InheritDemo {

	public static void main(String[] args) {
		Dog d = new Dog();
		d.eat();
		d.eatType();
		d.walk();
	}

}
