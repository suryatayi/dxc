package Abstract;
import java.util.*;

public class CollectionDemo {
	public static void main(String[] args) {
		ArrayList names = new ArrayList();
		names.add("surya");
		names.add("sumanth");
		names.add("tayi");
		names.add("sailu");
		System.out.println(names);
		
		names.add(2,"venkata");
		System.out.println(names);
		
		System.out.println(names.contains("surya"));
		System.out.println(names.size());

	}

}
