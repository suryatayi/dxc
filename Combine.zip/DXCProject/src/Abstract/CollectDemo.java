package Abstract;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class CollectDemo {

	public static void main(String[] args) {
		Set set = new TreeSet();
		Set s = new HashSet();
		Set s1 = new LinkedHashSet();

		set.add("surya");
		set.add("sumanth");
		set.add("Aishwarya");
		set.add("Bharathi");
		set.add("Lal");
		
		
		s.add("surya");
		s.add("sumanth");
		s.add("Aishwarya");
		s.add("Bharathi");
		s.add("Lal");
		
		
		s1.add("surya");
		s1.add("sumanth");
		s1.add("Aishwarya");
		s1.add("Bharathi");
		s1.add("Lal");
		
		
		System.out.println(set);
		System.out.println(s);
		System.out.println(s1);

	}

}
