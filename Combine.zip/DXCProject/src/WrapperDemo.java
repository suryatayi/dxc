//Wrapper classes

public class WrapperDemo {

 public static void main(String[] args) {
  String m= "12";
  Integer i = Integer.parseInt(m);
  System.out.println(i+10);
  
  Integer p = 10;
  String str = String.valueOf(p);
  System.out.println(str+9);
 
 }
}
