
public class HashEqualDemo {
    private int eid;
    private String empname;
    private int salary;	
    public HashEqualDemo(int eid, String empname, int salary) {
		super();
		this.eid = eid;
		this.empname = empname;
		this.salary = salary;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + eid;
		result = prime * result + ((empname == null) ? 0 : empname.hashCode());
		result = prime * result + salary;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HashEqualDemo other = (HashEqualDemo) obj;
		if (eid != other.eid)
			return false;
		if (empname == null) {
			if (other.empname != null)
				return false;
		} else if (!empname.equals(other.empname))
			return false;
		if (salary != other.salary)
			return false;
		return true;
	}

	public static void main(String[] args) {
		HashEqualDemo demo1= new HashEqualDemo(10, "surya", 25000);
		HashEqualDemo demo2= new HashEqualDemo(10, "surya", 25000);
		System.out.println(demo1.equals(demo2));
		System.out.println(demo1.hashCode());
		System.out.println(demo2.hashCode());

	}

}
