
public class StringDemo1 {

	public static void main(String[] args) {
		StringBuilder name = new StringBuilder("venkata ");
		name.append("surya ");
		name.append("tayi");
		System.out.println(name);
	}

}
