/**
 * 
 * this program was created by surya tayi
 *
 */
public class Hello {
	/**
	 * 
	 * this program was created by inside surya tayi
	 */
	public static void main(String[] args) {
		// this is suryas details
		  
		System.out.println("Hello Surya");
		System.out.println("How are you??");
	}

}
