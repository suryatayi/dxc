import java.util.Scanner;

public class Demo {


	 int num1, num2, result;

	 public void display() {
	  Scanner sc = new Scanner(System.in);

	  System.out.println("Please enter first number :");
	  num1 = sc.nextInt();

	  System.out.println("Please enter second number :");
	  num2 = sc.nextInt();

	 
	   try {
		result = num1 / num2;
	} catch (Exception e) {
		System.out.println("Some problem");
	}
	System.out.println("The result is : " + result);
	 }

	 public static void main(String[] args) {
	  System.out.println("Hello, Program started");
	  Demo d = new Demo();
	  d.display();
	  System.out.println("Bye, Program ended");
	 }
	}