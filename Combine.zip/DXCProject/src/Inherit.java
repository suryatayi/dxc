class Animal{
	int age =10;
	void eat() {
		System.out.println("Animal should eat");
	}
}
class Dog extends Animal{
	public void dogdetails() {
	int age =5;
	System.out.println("The age of dog is:"+age);
}
}
public class Inherit {
	public static void main(String[] args) {
		Dog d = new Dog();
		d.dogdetails();
		d.eat();
	}
}
