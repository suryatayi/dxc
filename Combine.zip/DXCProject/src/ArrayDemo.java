
public class ArrayDemo {
	int marks[] = new int[5];
	String names[]= {"surya","venkata","sumanth","tayi","lal","eashwar"};
	public void display() {
		marks[0] = 90;
		System.out.println(marks[0]);
		
		System.out.println("print all the names");
		System.out.println(names[2]);
	}
	public static void main(String[] args) {
		ArrayDemo a = new ArrayDemo();
		a.display();
	}

}
