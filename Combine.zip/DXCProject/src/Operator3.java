import java.util.Scanner;

public class Operator3 {
	Scanner sc = new Scanner(System.in);
	int marks=0;
	public void display()
	{
		System.out.print("enter marks");
		marks= sc.nextInt();
		if(marks>33)
		{
			System.out.println("Congrats you have cleared the exam ");
			System.out.println("You can apply for next process ");
		}
		else
		{
			System.out.println("Appear for RE exam ");
		}
		
	}

	public static void main(String[] args) {
		System.out.println("Program Started ");
		Operator3 o =new Operator3();
		o.display();
	}
 
}