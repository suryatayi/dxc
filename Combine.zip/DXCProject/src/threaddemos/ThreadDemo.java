package threaddemos;

public class ThreadDemo extends Thread {
Thread t1;
public ThreadDemo()
{
	t1 = new Thread(this);
	t1.start();
}
	@Override
	public void run() {
		System.out.println(" Start RUN CALLED by:" +Thread.currentThread().getName());
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" End RUN CALLED by:" +Thread.currentThread().getName());

	}
	public static void main(String[] args) {
		new ThreadDemo();
		System.out.println("Program Started:" +ThreadDemo.currentThread().getName());

	}

}
