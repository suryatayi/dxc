package threaddemos;
//multple threads 
public class ThreadDemo2 extends Thread {
Thread t1,t2;
public ThreadDemo2()
{
	t1 = new Thread(this);
	t2 = new Thread(this);
	t1.start();
	t2.start();
}
	@Override
	public void run() {
		System.out.println(" Start RUN CALLED by:" +Thread.currentThread().getName());
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println(" End RUN CALLED by:" +Thread.currentThread().getName());

	}
	public static void main(String[] args) {
		new ThreadDemo2();
		System.out.println("Program Started:" +ThreadDemo2.currentThread().getName());

	}

}
