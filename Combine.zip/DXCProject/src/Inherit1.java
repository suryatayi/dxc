class Animals{
	int age =1;
	void eat() {
		System.out.println("Animal should eat");
	}
}
class Cat extends Animals{
	int age =10;
	public void dogdetails() {
	int age =5;
	System.out.println("The age of dog is:"+age);
	System.out.println("The age of dog is:"+this.age);
	System.out.println("The age of dog is:"+super.age);
}
	public void eat() {
	super.eat();
	System.out.println("Dog eats meat");
	}
}
public class Inherit1 {
	public static void main(String[] args) {
		Cat c = new Cat();
		c.dogdetails();
		c.eat();
	}
}

