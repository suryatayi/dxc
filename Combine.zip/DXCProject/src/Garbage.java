
public class Garbage {
	public void finalize() {
		System.out.println("finilized");
	}

	public static void main(String[] args) {
		Garbage garbage1 = new Garbage();
		Garbage garbage2 = new Garbage();
		System.out.println("initialized");
		garbage1 = null;
		garbage2 = null;
		System.gc(); //run to gc

	}

}
