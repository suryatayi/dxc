//program to see use of constants in java
public class Constant {
	final int TOTAL_SCORE=100;
	public void same() {
		System.out.println("the maximum score is:"+TOTAL_SCORE);
	
	}

	public static void main(String[] args) {
		Constant c= new Constant();
		c.same();
			

	}

}
