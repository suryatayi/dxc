
public class Student {
	// calss declaration 
	String studenname;
	int marks;
	int i;
	public void display()
	{
		//local variable
		String email=null;
		int j=0;
		System.out.println(i+j);
		System.out.println(email);
	}
	public static void main(String[] args) {
		Student s = new Student();
		s.display();
		

	}

}
