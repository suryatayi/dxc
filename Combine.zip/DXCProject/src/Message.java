
public class Message {
	
	public void dxcopening() {
		System.out.println("DXC will continue Work from home till september 30th 2020");
	}
	
	public void display() {
		System.out.println("Hello from display");
		Message m = new Message();
		m.dxcopening();
		System.out.println("Bye from display");
	}

	public static void main(String[] args) {
		System.out.println("Hello from main");
		Message m = new Message();
		m.display();
		System.out.println("Bye from main");
	}

}
