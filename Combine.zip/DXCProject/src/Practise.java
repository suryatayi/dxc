import java.util.Scanner;


public class Practise {
	Scanner sc =new Scanner(System.in);
	int num1;
	int num2;
	int add;
	public void display() {
		System.out.print("Enter num1:");
		num1 = sc.nextInt();
		System.out.print("Enter num2:");
		num2 = sc.nextInt();
		add = num1+num2;
		
		System.out.println("sum is :" +add);
	}
	public static void main(String[] args) {
		Practise d = new Practise();
		d.display();
	}

}
