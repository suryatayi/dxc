package org.animals;

public class Lion {
	String colour ="Yellow";
	float weight= (float) 190.5;
	int age = 8; 
	public void vegetarian() {
		
		System.out.println("Lion is not a vegetarian");
	}
	public void canClimb() {
		System.out.println("Lion cant climb ");
		
	}
	public void getSound() {
		System.out.println("Lion sounds lika a pro ");
		
	}
	public void liondetails() {
		System.out.println("-------Lion------- ");
		System.out.println("Lion Colour is:"+colour);
		System.out.println("Lion Weight in kg's is:"+weight);
		System.out.println("Lion Age in years is:"+age);
	}
		
}
