package com.dxc.pms.client;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.dxc.pms.dbcon.MyConnection;

public class Client { 

public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection con = MyConnection.getDBConnection();
 
        while (true) {
 
            System.out.println("MAIN MENU");
            System.out.println("1. Add Customer");
            System.out.println("2. Delete Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Find Customer by Id");
            System.out.println("5. Find All Customer Details ");
            System.out.println("6. E X I T");
            System.out.print("Please enter your choice (1-6)");
            int choice = scanner.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Adding Customers : ");
                break;
            case 2:
                System.out.println("Deleting Customers : ");
                break;
            case 3:
                System.out.println("Updating Customers : ");
                break;
            case 4:
                System.out.println("Finding Customers by id : ");
                break;
            case 5:
                System.out.println("Displaying all the  Customer Details : ");
                Statement statement= con.createStatement();
                ResultSet res = statement.executeQuery("select * from hr.customer");
                while(res.next()) {
                	System.out.println(res.getString(1)+ " ");
                	System.out.println(res.getString(2)+ " ");
                }
                break;
            case 6:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option Please select (1-6)");
            }
        }
    }
}
