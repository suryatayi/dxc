package games;

public class Cricket {
	public void playcricket() {
		System.out.println("Students play cricket");
	}

}
