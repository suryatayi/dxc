package games;

public class Football {
	public void playfootball() {
	System.out.println("Students play football");
	

}
}