import games.Football;

public class Client {

	public static void main(String[] args) {
		System.out.println("client details");
		Student s = new Student();
		s.displaystudentdetails();
		Teacher t = new Teacher();
		t.takeclasses();
		Football f = new Football();
		f.playfootball();
	}

}
