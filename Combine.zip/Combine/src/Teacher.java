
public class Teacher {
	public void takeclasses() {
		System.out.println("Teacher takes classes");
	}

	}
