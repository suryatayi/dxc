
public class Fee {
	public void takefees() {
		System.out.println("please pay the fees on time");
	}

}
