
public class Student {

	public  void displaystudentdetails() {
		System.out.println("Display Student Details");
		Fee f = new Fee();
		f.takefees();
	}

}
