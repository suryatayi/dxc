package hr;
import java.util.Scanner;

public class Manager {
		Scanner sc = new Scanner (System.in);
		String ManagerName;
		public void name() {
			System.out.print("Enter Manager Name:");
			ManagerName = sc.next();
		}		
	}

