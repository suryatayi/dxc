package finance.gst;
import java.util.Scanner;
public class Cgst {
				Scanner sc = new Scanner(System.in);
				int cgst;
				public void centraltax() {
					System.out.print("Enter central tax amount:");
					cgst = sc.nextInt();	
				}

			}

