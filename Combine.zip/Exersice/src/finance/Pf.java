package finance;
import java.util.Scanner;

public class Pf {
	Scanner sc = new Scanner(System.in);
		int amount;
		public void price() {
			System.out.print("Enter PF price:");
			amount = sc.nextInt();	
		}

	}
