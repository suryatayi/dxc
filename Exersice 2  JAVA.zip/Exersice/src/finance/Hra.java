package finance;
import java.util.Scanner;

public class Hra {
			Scanner sc = new Scanner(System.in);
			int hra;
			public void basicsalary() {
				System.out.print("Enter  HRA Sum of basic salary:");
				hra = sc.nextInt();	
			}

		}
