package finance.gst;
import java.util.Scanner;

public class Sgst {
					Scanner sc = new Scanner(System.in);
					int sgst;
					public void statetax() {
						System.out.print("Enter state tax amount:");
						sgst = sc.nextInt();	
					}

				}

