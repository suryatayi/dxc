package finance;
import java.util.Scanner;


public class Salary {
	Scanner sc = new Scanner(System.in);
	int salary;
	public void amount() {
		System.out.print("Enter Salary:");
		salary = sc.nextInt();	
	}

}
