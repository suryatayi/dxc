import finance.Hra;
import finance.Pf;
import finance.Salary;
import finance.gst.Cgst;
import finance.gst.Sgst;
import hr.Employee;
import hr.Manager;

public class Client {

	public static void main(String[] args) {
		Employee e = new Employee();
		e.id();
		Manager m = new Manager();
		m.name();
		Salary s = new Salary();
		s.amount();
		Pf p = new Pf();
		p.price();
		Hra h = new Hra();
		h.basicsalary();
		Cgst c = new Cgst();
		c.centraltax();
		Sgst t = new Sgst();
		t.statetax();

	}

}
