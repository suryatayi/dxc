package hr;

import java.util.Scanner;

public class Employee {
	Scanner sc = new Scanner (System.in);
	int employeeid;
	public void id(){
		System.out.print("Enter employee id:");
		employeeid = sc.nextInt();
	}
}