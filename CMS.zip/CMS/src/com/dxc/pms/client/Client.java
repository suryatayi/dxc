package com.dxc.pms.client;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.dxc.pms.dbcon.MyConnection;

public class Client { 
	static Scanner scanner = new Scanner(System.in);    
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	Connection con = MyConnection.getDBConnection();
 
        while (true) {
 
            System.out.println("MAIN MENU");
            System.out.println("1. Add Customer");
            System.out.println("2. Delete Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Find Customer by Id");
            System.out.println("5. Find All Customer Details ");
            System.out.println("6. E X I T");
            System.out.print("Please enter your choice (1-6)");
            int choice = scanner.nextInt();
            switch (choice) {
            case 1:
                System.out.println("Adding Customers : ");
                addcustomers(con);
                break;
            case 2:
                System.out.println("Deleting Customers : ");
                deletecustomers(con);
                break;
            case 3:
                System.out.println("Updating Customers : ");
                updatecustomers(con);
                break;
            case 4:
                System.out.println("Finding Customers by id : ");
                displaycustomersById(con);
                break;
            case 5:
                displaydetails(con);
                break;
            case 6:
                System.out.println("Thanks for using my program");
                System.exit(0);
            default:
                System.out.println("Incorrect Option Please select (1-6)");
            }
        }
    }
private static void displaydetails(Connection con) throws SQLException {
	 System.out.println("Displaying all the  Customer Details : ");
     Statement statement= con.createStatement();
     ResultSet res = statement.executeQuery("select * from hr.customer");
   //metadata
 	ResultSetMetaData rsmd =res.getMetaData();
 	
 	int columnNumber = rsmd.getColumnCount();
 	
 	for(int i =1;i<=columnNumber;i++)
 	{
 		System.out.print(rsmd.getColumnName(i)+"  ");
 	}
 	System.out.println();
 	while(res.next()) {
 		for(int i = 1;i <= columnNumber;i++) {
 			System.out.print(res.getString(i)+" ");
 		}
 		System.out.println();
 		
 		}
}

private static void displaycustomersById(Connection con) throws SQLException {
	System.out.println("customers displaying by id:");
	System.out.println("customers enter the customer id to search:");
	int customerid = scanner.nextInt();
	System.out.println("You want to Search for :" +customerid);
	PreparedStatement stat= con.prepareStatement("select * from hr.customer where customerid = ?");
	stat.setInt(1, customerid);
	ResultSet res = stat.executeQuery();
	if(res.next()) {
		System.out.println(res.getString(1)+ " ");
		System.out.println(res.getString(2)+ " ");
	
	}

}	

private static void updatecustomers(Connection con) throws SQLException {
	System.out.println("Enter customer id to update : ");int customerid= scanner.nextInt();
	System.out.println("Enter customer name to update : ");String customerName= scanner.next();

	PreparedStatement statement = con.prepareStatement("update hr.customer set customerName =? where customerid=?");
	statement.setInt(2, customerid);
	statement.setString(1, customerName);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(customerName+",successfully updated");	
}	
private static void deletecustomers(Connection con) throws SQLException {
System.out.println("Enter customer id : ");int customerid= scanner.nextInt();
	
	PreparedStatement statement = con.prepareStatement("delete from hr.customer where customerid = ?");
	statement.setInt(1, customerid);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(customerid+",successfully deleted");	
}
private static void addcustomers(Connection con) throws SQLException {
	System.out.println("Enter cusromer id : ");int customerid= scanner.nextInt();
	System.out.println("Enter customer name : ");String customerName= scanner.next();

	PreparedStatement statement = con.prepareStatement("insert into hr.customer values(?,?)");
	statement.setInt(1, customerid);
	statement.setString(2, customerName);
	
	int rows = statement.executeUpdate();
	System.out.println(rows+",affected");
	System.out.println(customerName+",successfully saved");
}	
}
