package org.animals;

public class Monkey {
	String colour = "Brown";
	float weight = 26;
	int age = 7;  
	public void vegetarian() {
		
		System.out.println("Monkeys are omnivores");
	}
	public void canClimb() {
		System.out.println("Monkeys can climb ");
		
	}
	public void getSound() {
		System.out.println("Monkeys can sound ");
		
	}
	public void monkeydetails() {
		System.out.println("-------Monkey------- ");
		System.out.println("Monkey colour is:"+colour);
		System.out.println("Monkey Weight in kg's is:"+weight);
		System.out.println("Monkey Age is:"+age);
	}
		
}
